import matplotlib.pyplot as plt

plt.ioff()
plt.plot([c for c in range(0, 100)], [k for k in range(30, 130)], '.k')
plt.pause(0.001)
plt.plot([i for i in range(0, 100)], [l for l in range(0, 100)], '.b')
plt.pause(0.001)
plt.legend(['d', 'b'])
plt.pause(0.001)
plt.show()
